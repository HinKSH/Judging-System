﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _3080
{
    /// <summary>
    /// Edit.xaml 的互動邏輯
    /// </summary>
    public partial class Edit : Window
    {
        public void AddItems(Array problem, ComboBox newitems)
        {
            foreach (var obj in problem)
            {
                newitems.Items.Add(obj);
            }
        }
        public Edit()
        {
            InitializeComponent();
            string[] problem = new string[10];
            problem = GloVar.problem;
            AddItems(problem, newitems);
        }

        private void add_button_Click(object sender, RoutedEventArgs e)
        {
            int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
            GloVar.newcode[questionNumber] = txt_edit_Code.Text;
            GloVar.newcase[questionNumber] = txt_edit_Case.Text;
            if (questionNumber == 2)
            {
                GloVar.testcase[questionNumber] = txt_edit_Case2.Text;
                GloVar.newcase[questionNumber] = txt_edit_Case.Text;
                GloVar.new_output[2] = txt_edit_Case.Text;
                GloVar.parlindrome_test_out = GloVar.new_output[2].Split(',');
                GloVar.new_input[2] = txt_edit_Case2.Text;
                GloVar.parlindrome_test_in = GloVar.new_input[2].Split(',','\n');
                if (GloVar.parlindrome_test_in.Count() >= 3)
                {

                    GloVar.wrong_testcase = false;
                }else
                GloVar.wrong_testcase = true;
            }
            else if (questionNumber == 0)
            {
                GloVar.hello_output[0] = txt_edit_Case2.Text;
            }
            else
            { 
                
            }
            MessageBox.Show("Changes are made and saved!");
        }

        private void select_Click(object sender, RoutedEventArgs e)
        {
            string option = newitems.Text;
            if (option == "")
            {
                MessageBox.Show("No Question is selected. Please select a Question!");
            }
            else
            {
                GloVar.qchoose = option;
                if (option == "Hello World")
                {
                    if (GloVar.newcase[0]==null)
                    {
                        GloVar.newcase[0] = "Hello World";
                    }
                }
                int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
                if (questionNumber == 1)
                {
                    txt_edit_Case2.Text = string.Format("{0}" + "," + "{1}", GloVar.prime_input[0], GloVar.prime_input[1]);
                    txt_edit_Code.Text = string.Format("{0}", GloVar.newcode[questionNumber]);
                    txt_edit_Case.Text = string.Format("{0}" + "," + "{1}", GloVar.prime_output[0], GloVar.prime_output[1]);

                }
                else if (questionNumber == 0)
                {
                    txt_edit_Code.Text = string.Format("{0}", GloVar.newcode[questionNumber]);
                    txt_edit_Case.Text = string.Format("{0}", GloVar.newcase[questionNumber]);
                    txt_edit_Case2.Text = string.Format("{0}", GloVar.newcase[questionNumber]);
                }
                else 
                {
                    
                    txt_edit_Code.Text = string.Format("{0}", GloVar.newcode[questionNumber]);
                    txt_edit_Case.Text = string.Format("{0}" + "," + "{1}", GloVar.parlindrome_test_out[0], GloVar.parlindrome_test_out[1]);
                    if (GloVar.parlindrome_test_in.Count() >= 3) 
                    {
                        txt_edit_Case2.Text = string.Format("{0}" + "," + "{1}"+","+"{2}", GloVar.parlindrome_test_in[0], GloVar.parlindrome_test_in[1], GloVar.parlindrome_test_in[2]);
                    }
                    else
                        txt_edit_Case2.Text = string.Format("{0}" + "," + "{1}", GloVar.parlindrome_test_in[0], GloVar.parlindrome_test_in[1]);
                }


            }
        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
            admin admin = new admin();
            admin.Show();
            this.Close();

        }
    }
}
