﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _3080
{
    /// <summary>
    /// statisticpage.xaml 的互動邏輯
    /// </summary>
    public partial class statisticpage : Window
    {
        public statisticpage()
        {
            InitializeComponent();
            TitleBox.Text = string.Format("Statistic of {0}", GloVar.qchoose);
            int i = Array.IndexOf(GloVar.problem, GloVar.qchoose);
            if (GloVar.qchoose == "Hello World")
            {
                if (GloVar.succ_attp[0] == 0 && GloVar.total[i] == 0)
                {
                    GloVar.succ_attp[0] = 1;
                    GloVar.total[0] = 1;
                    GloVar.stdID_1[0] = 1;
                }
            }
            AC_STAT.Text = string.Format("{0}", GloVar.succ_attp[i]);
            Total_stat.Text = string.Format("{0}", GloVar.total[i]);
        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
            Question_Stat stat = new Question_Stat();
            stat.Show();
            this.Close();
        }
    }
}
