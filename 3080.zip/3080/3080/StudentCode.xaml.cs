﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.CodeDom.Compiler;
using System.Windows.Forms;
using System.Diagnostics;
using MessageBox = System.Windows.MessageBox;

namespace _3080
{
    /// <summary>
    /// StudentCode.xaml 的互動邏輯
    /// </summary>
    

    public partial class StudentCode : Window
    {
        public StudentCode()
        {
            InitializeComponent();
            QuestionTitle.Text = string.Format("{0}", GloVar.qchoose);
        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
           
            this.Close();
        }

        private void upload_button_Click(object sender, RoutedEventArgs e)
        {

            OpenFileDialog file = new OpenFileDialog();
            file.ShowDialog();
            GloVar.path = file.FileName;
            txtpath.Text = GloVar.path;
        }
        public void Gcc(string input_path, string exe_path)
        {
            File.Delete(exe_path);
            string strCmdText = "gcc -o " + exe_path + " " + input_path;
            
            Process gcc = new Process();
            gcc.StartInfo = new ProcessStartInfo()
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
                FileName = "cmd.exe",
                Arguments = "/C " + strCmdText,
                RedirectStandardError = true
            };
            gcc.Start();
            gcc.WaitForExit();
        }
        public void submit_student_file(string input_path)
        {
            
            int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
            
            string exe_path = input_path.Replace(".c", ".exe");
            Gcc(input_path, exe_path);
            string testcase = GloVar.newcase[questionNumber];

            string program_output = Run_exe(exe_path, testcase);
           
        }
        public void submit_student_file_try(string input_path)
        {
            int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);

            string exe_path = input_path.Replace(".c", ".exe");
            Gcc(input_path, exe_path);
            string testcase = GloVar.newcase[questionNumber];

            string program_output = Run_exe_try(exe_path, testcase);
        }
      
        public string Run_exe(string exe_path, string input)
        {
            string path = exe_path.Replace(".exe",".c");
            string strCmdText = "gcc -o " + exe_path + " " + path;
            Process.Start("CMD.exe", "/C " + strCmdText);

            Process process = new Process();
            process.StartInfo = new ProcessStartInfo()
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
                FileName = "cmd.exe",
                Arguments = "/C " + exe_path,
                RedirectStandardInput = true,
                RedirectStandardError = true,
                RedirectStandardOutput = true
            };
            
            process.Start();
            
           
            
            int index = Array.IndexOf(GloVar.problem, GloVar.qchoose);
            //string[] test = GloVar.testcase[index].Split(new char[] {','});

            if (GloVar.qchoose == "Prime")
            {
                process.StandardInput.WriteLine(GloVar.prime_input[0]);
                process.StandardInput.WriteLine(GloVar.prime_input[1]);
                string program_output1 = process.StandardOutput.ReadLine();
                string program_output2 = process.StandardOutput.ReadToEnd();
                MessageBox.Show(program_output1);
                MessageBox.Show(program_output2);
                //cmdoutput.Text = program_output1 + " " + program_output2;
                process.WaitForExit();
                MessageBox.Show(exe_path);
                int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
                if (program_output1 == GloVar.prime_output[0] && program_output2 == GloVar.prime_output[1])
                {
                    MessageBox.Show("Program Correct");
                    if (GloVar.stdID == 1)
                    {
                        GloVar.stdID_1[index] = 1;
                    }
                    else if (GloVar.stdID == 2)
                    {
                        GloVar.stdID_2[index] = 1;
                    }
                    else if (GloVar.stdID == 3)
                    {
                        GloVar.stdID_3[index] = 1;
                    }
                    GloVar.total[questionNumber] = GloVar.total[questionNumber] + 1;
                    GloVar.succ_attp[questionNumber] = GloVar.succ_attp[questionNumber] + 1;
                }
                else
                {
                    MessageBox.Show("Program Wrong");
                    GloVar.total[questionNumber] = GloVar.total[questionNumber] + 1;
                }
            }
            else if (GloVar.qchoose == "Hello World")
            {
                process.StandardInput.WriteLine("");
                string program_output1 = process.StandardOutput.ReadLine();
                MessageBox.Show(program_output1);
                int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
                if (program_output1 == GloVar.hello_output[0])
                {
                    MessageBox.Show("Program Correct");
                    if (GloVar.stdID == 1)
                    {
                        GloVar.stdID_1[index] = 1;
                    }
                    else if (GloVar.stdID == 2)
                    {
                        GloVar.stdID_2[index] = 1;
                    }
                    else if (GloVar.stdID == 3)
                    {
                        GloVar.stdID_3[index] = 1;
                    }
                    GloVar.total[questionNumber] = GloVar.total[questionNumber] + 1;
                    GloVar.succ_attp[questionNumber] = GloVar.succ_attp[questionNumber] + 1;
                }
                else
                {
                    MessageBox.Show("Program Wrong");
                    GloVar.total[questionNumber] = GloVar.total[questionNumber] + 1;
                }
            }
            else 
            {
                process.StandardInput.WriteLine(GloVar.parlindrome_test_in[0]);
                process.StandardInput.WriteLine(GloVar.parlindrome_test_in[1]);
                string program_output1 = process.StandardOutput.ReadLine();
                string program_output2 = process.StandardOutput.ReadToEnd();
                //cmdoutput.Text = program_output1 + " " + program_output2;
                process.WaitForExit();
                int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
                if (program_output1 == GloVar.parlindrome_test_out[0] && program_output2 == GloVar.parlindrome_test_out[1]&&GloVar.wrong_testcase==true)
                {
                    MessageBox.Show("Program Correct");
                    if (GloVar.stdID == 1)
                    {
                        GloVar.stdID_1[index] = 1;
                    }
                    else if (GloVar.stdID == 2)
                    {
                        GloVar.stdID_2[index] = 1;
                    }
                    else if (GloVar.stdID == 3)
                    {
                        GloVar.stdID_3[index] = 1;
                    }
                    GloVar.total[questionNumber] = GloVar.total[questionNumber] + 1;
                    GloVar.succ_attp[questionNumber] = GloVar.succ_attp[questionNumber] + 1;
                }
                else
                {
                    MessageBox.Show("Program Wrong");
                    GloVar.total[questionNumber] = GloVar.total[questionNumber] + 1;
                }
            }
            return null;
        }
        public string Run_exe_try(string exe_path, string input)
        {
            string path = exe_path.Replace(".exe", ".c");
            string strCmdText = "gcc -o " + exe_path + " " + path;
            Process.Start("CMD.exe", "/C " + strCmdText);

            Process process = new Process();
            process.StartInfo = new ProcessStartInfo()
            {
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden,
                FileName = "cmd.exe",
                Arguments = "/C " + exe_path,
                RedirectStandardInput = true,
                RedirectStandardError = true,
                RedirectStandardOutput = true
            };

            process.Start();



            int index = Array.IndexOf(GloVar.problem, GloVar.qchoose);
            //string[] test = GloVar.testcase[index].Split(new char[] {','});

            if (GloVar.qchoose == "Prime")
            {
                process.StandardInput.WriteLine(GloVar.prime_input[0]);
                process.StandardInput.WriteLine(GloVar.prime_input[1]);
                string program_output1 = process.StandardOutput.ReadLine();
                string program_output2 = process.StandardOutput.ReadToEnd();
                MessageBox.Show(program_output1);
                MessageBox.Show(program_output2);
                //cmdoutput.Text = program_output1 + " " + program_output2;
                process.WaitForExit();
                int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
                if (program_output1 == GloVar.prime_output[0] && program_output2 == GloVar.prime_output[1])
                {
                    MessageBox.Show("Program Correct");
                    
                }
                else
                {
                    MessageBox.Show("Program Wrong");

                }
            }
            else if (GloVar.qchoose == "Hello World")
            {
                process.StandardInput.WriteLine("");
                string program_output1 = process.StandardOutput.ReadLine();
                int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
                if (program_output1 == GloVar.hello_output[0])
                {
                    MessageBox.Show("Program Correct");
                    
                }
                else
                {
                    MessageBox.Show("Program Wrong");
                    
                }
            }
            else
            {
                process.StandardInput.WriteLine(GloVar.parlindrome_test_in[0]);
                process.StandardInput.WriteLine(GloVar.parlindrome_test_in[1]);
                string program_output1 = process.StandardOutput.ReadLine();
                string program_output2 = process.StandardOutput.ReadToEnd();
                //cmdoutput.Text = program_output1 + " " + program_output2;
                process.WaitForExit();
                int questionNumber = Array.IndexOf(GloVar.problem, GloVar.qchoose);
                if (program_output1 == GloVar.parlindrome_test_out[0] && program_output2 == GloVar.parlindrome_test_out[1])
                {
                    MessageBox.Show("Program Correct");
                    GloVar.succ_attp[questionNumber] = GloVar.succ_attp[questionNumber] + 1;
                }
                else
                {
                    MessageBox.Show("Program Wrong");
                   
                }
            }
            return null;
        }
        public string create_program_file(string code)
        {
            string filename = GloVar.qchoose;
            filename = filename.Replace(" ", "");
            filename = filename.ToLower();
            string filepath = "/Documents/" + filename + ".c";
            FileInfo file = new FileInfo(filepath);
            file.Directory.Create();
            File.WriteAllText(filepath, code);
            return filepath;
        }
        private void submitButton_Click(object sender, RoutedEventArgs e)
        {

            if (!String.IsNullOrEmpty(txtCode.Text))
            {
                MessageBox.Show("Get code from Text");
                GloVar.path = create_program_file(txtCode.Text);
                MessageBox.Show(GloVar.path);
                submit_student_file(GloVar.path);
            }
            else if (!String.IsNullOrEmpty(txtpath.Text))
            {
                MessageBox.Show("Open file");
                submit_student_file(GloVar.path);
            }
            else MessageBox.Show("Please write your code or submit your program file.");
        }

        private void try_button_Click(object sender, RoutedEventArgs e)
        {
            if (!String.IsNullOrEmpty(txtCode.Text))
            {
                MessageBox.Show("Get code from Text");
                GloVar.path = create_program_file(txtCode.Text);
                MessageBox.Show(GloVar.path);
                submit_student_file_try(GloVar.path);
            }
            else if (!String.IsNullOrEmpty(txtpath.Text))
            {
                MessageBox.Show("Open file");
                submit_student_file_try(GloVar.path);
            }
            else MessageBox.Show("Please write your code or submit your program file.");
        }
    }
}
