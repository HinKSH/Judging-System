﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _3080
{
    /// <summary>
    /// Question_List.xaml 的互動邏輯
    /// </summary>
    public partial class Question_List : Window
    {
        public Question_List()
        {
            InitializeComponent();
            int num = GloVar.problem.Count();
            for (int i = 0; i < num; i++)
            {
                list.Items.Add(GloVar.problem[i]);

            }

        }

        private void list_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string option = list.Text;
            if (option == "")
            {
                MessageBox.Show("Please choose a question");
            }
            else
            {
                GloVar.qchoose = option;
                StudentCode stdCode = new StudentCode();
                stdCode.Show();
                this.Close();
            }

        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
            student std = new student();    
            std.Show(); 
            this.Close();
        }
    }
}
