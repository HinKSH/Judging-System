﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _3080
{
    /// <summary>
    /// AddNewQuestion.xaml 的互動邏輯
    /// </summary>
    public partial class AddNewQuestion : Window
    {
        public AddNewQuestion()
        {
            InitializeComponent();
        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
            admin ad = new admin();
            ad.Show();
            this.Close();
        }

        private void add_button_Click(object sender, RoutedEventArgs e)
        {
            string newprob = txtName.Text;
            string newcase = txtCase.Text;
            string newcase2 = txtoutput.Text;

            int i = 0;

            if ((newprob != "") && (newcase != ""))
            {
                for (i = 0; i <= 10; i++)
                {
                    if (GloVar.problem[i] == null)
                    {
                        GloVar.new_input[i] = txtCase.Text;
                        GloVar.parlindrome_test_in = GloVar.new_input[i].Split(',','\n');
                        GloVar.new_output[i] = txtoutput.Text;
                        GloVar.parlindrome_test_out = GloVar.new_output[i].Split(',');
                        GloVar.problem[i] = txtName.Text;
                        GloVar.total[i] = 0;
                        GloVar.succ_attp[i] = 0;
                        GloVar.wrong_testcase = true;
                        MessageBox.Show("Question " + GloVar.problem[i] + " Added!");
                        admin admin = new admin();
                        admin.Show();
                        this.Close();
                        break;
                    }
                }
            }
            else
            {
                MessageBox.Show("Missing Information!");
            }
        }
    }
}
