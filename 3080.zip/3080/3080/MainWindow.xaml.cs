﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.IO;

namespace _3080
{
    /// <summary>
    /// MainWindow.xaml 的互動邏輯
    /// </summary>

    public class GloVar
    {
        public static string[] problem = new string[10];
        public static int[] succ_attp = new int[10];
        public static int[] total = new int[10];
        public static string qchoose;
        public static string[] newquestion = new string[10];
        public static string path;
        public static string[] newcode = new string[10];
        public static string[] newcase = new string[10];
        public static string[] newcase2 = new string[10];
        public static int stdID;
        public static int[] stdID_1 = new int[10];
        public static int[] stdID_2 = new int[10];
        public static int[] stdID_3 = new int[10];
        public static int[] stdID_4 = new int[10];
        public static int[] stdID_5 = new int[10];
        public static int[] stdID_6 = new int[10];
        public static string[] testcase = new string[10];
        public static string[] prime_input = new string[10];
        public static string[] prime_output = new string[10];
        public static string[] hello_output = new string[10];
        public static string[] new_output = new string[10];
        public static string[] new_input = new string[10];
        public static string[] parlindrome_test_in = new string[10];
        public static string[] parlindrome_test_out = new string[10];
        public static bool wrong_testcase;
    }
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            GloVar.problem[0] = "Hello World";
            GloVar.problem[1] = "Prime";
            GloVar.newcase2[0] = "";

            GloVar.hello_output[0] = "Hello World";
            GloVar.prime_input[0] = "2";
            GloVar.prime_output[0] = "Prime";
            GloVar.prime_input[1] = "4";
            GloVar.prime_output[1] = "Not prime";
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            string user = txtUserName.Text;
            string pass = txtUserPassword.Password;

            
            if (user == "ChanSiuMing" && pass == "200000101")
            {
                GloVar.stdID = 1;
                MessageBox.Show("Login Success");
                student a = new student();
                a.Show();
                txtUserPassword.Clear();
                txtUserName.Clear();  
                this.Close();
            } 
            else if (user == "ChanTaiMing" && pass == "asdfghjkl;'")
            {
                GloVar.stdID = 2;
                MessageBox.Show("Login Success");
                student a = new student();
                a.Show();
                txtUserPassword.Clear();
                txtUserName.Clear();
                this.Close();
            }
            else if (user == "Admin" && pass == "Admin")
            {
                MessageBox.Show("Login Success");
                admin b = new admin();
                b.Show();
                txtUserPassword.Clear();
                txtUserName.Clear(); 
                this.Close();
            }
            else if (user == "CatChu" && pass == "catcatcat")
            {
                GloVar.stdID = 3;
                MessageBox.Show("Login Success");
                student a = new student();
                a.Show();
                txtUserPassword.Clear();
                txtUserName.Clear();
                this.Close();
            }
            else if (user == "" && pass == "")
            {
                MessageBox.Show("Please type in login information");
            }
            else
                MessageBox.Show("Error");

        }

        private void exitButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }


}
