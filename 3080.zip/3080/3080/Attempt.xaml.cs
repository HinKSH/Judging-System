﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _3080
{
    /// <summary>
    /// Attempt.xaml 的互動邏輯
    /// </summary>
    public partial class Attempt : Window
    {
        public Attempt()
        {
            InitializeComponent();
            int num = GloVar.problem.Count();
            for (int i = 0; i < num; i++)
            {
                combo_att.Items.Add(GloVar.problem[i]);
            }
        }

        private void select_button_Click(object sender, RoutedEventArgs e)
        {
            string option = combo_att.Text;
            if (option == "")
            {
                MessageBox.Show("Please choose a question");
            }
            else
            {
                GloVar.qchoose = option;
                StudentCode code = new StudentCode();
                code.Show();
            }
        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
            admin ad = new admin();
            ad.Show();
            this.Close();
        }
    }
}
