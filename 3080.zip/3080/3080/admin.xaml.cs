﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _3080
{
    /// <summary>
    /// admin.xaml 的互動邏輯
    /// </summary>
    public partial class admin : Window
    {
        public admin()
        {
            InitializeComponent();
        }

        private void Logout__Click(object sender, RoutedEventArgs e)
        {
            MainWindow nw = new MainWindow();
            nw.Show();
            this.Close();
            
        }

        private void Statistic_Click(object sender, RoutedEventArgs e)
        {
            Question_Stat stat = new Question_Stat();
            stat.Show();
            this.Close ();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            AddNewQuestion nq = new AddNewQuestion();   
            nq.Show();
            this.Close();
        }

        private void attmpt_Click(object sender, RoutedEventArgs e)
        {
            Attempt at = new Attempt();
            at.Show();
            this.Close();
        }

        private void Edit_Problem_Click(object sender, RoutedEventArgs e)
        {
            Edit edit = new Edit();
            edit.Show();
            this.Close();
        }
    }
}
