﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _3080
{
    /// <summary>
    /// ProgressCheck.xaml 的互動邏輯
    /// </summary>
    public partial class ProgressCheck : Window
    {
        public void AddItems(Array problem, ComboBox newitems)
        {
            foreach (var obj in problem)
            {
                newitems.Items.Add(obj);
            }
        }
        public ProgressCheck()
        {
            InitializeComponent();
            string[] problem = new string[10];
            problem = GloVar.problem;
            AddItems(problem, combobox);
        }

        private void list_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string option = combobox.Text;
            if (option == "")
            {
                MessageBox.Show("Please choose a Question");
            }
            else
            {
                GloVar.qchoose = option;
                
                int index = Array.IndexOf(GloVar.problem, GloVar.qchoose);
                if (GloVar.stdID == 1)
                {
                    if (GloVar.stdID_1[index] == 1)
                    {
                        txtprog.Text = string.Format("Problem:{0}\n Status:Complete", GloVar.qchoose);
                    }
                    else
                    {
                        txtprog.Text = string.Format("Problem:{0}\n Status:Not Complete", GloVar.qchoose);
                    }

                }
                else if (GloVar.stdID == 2)
                {
                    if (GloVar.stdID_2[index] == 1)
                    {
                        txtprog.Text = string.Format("Problem:{0}\n Status:Complete", GloVar.qchoose);
                    }
                    else
                    {
                        txtprog.Text = string.Format("Problem:{0}\n Status:Not Complete", GloVar.qchoose);
                    }
                }
                else if (GloVar.stdID == 3)
                {
                    if (GloVar.stdID_3[index] == 1)
                    {
                        txtprog.Text = string.Format("Problem:{0}\n Status:Complete", GloVar.qchoose);
                    }
                    else
                    {
                        txtprog.Text = string.Format("Problem:{0}\n Status:Not Complete", GloVar.qchoose);
                    }
                }
                else
                {
                    MessageBox.Show("No Such Student Data");
                }
            }
        }

        private void return_button_Click(object sender, RoutedEventArgs e)
        {
            student student = new student();
            student.Show();
            this.Close();
        }
    }
}
