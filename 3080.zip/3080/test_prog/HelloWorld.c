﻿#include <stdio.h>
int main()
{
	// printf() 中字符串需要引号
	printf("Hello World");
	return 0;
}